Hand washing
============

Designer: Siwat V (https://www.iconfinder.com/antto)
