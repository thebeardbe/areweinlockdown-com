Coronavirus Flat
===========

Designer: Becris (https://www.iconfinder.com/becris)
