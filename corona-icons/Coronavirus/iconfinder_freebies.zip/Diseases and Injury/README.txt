Diseases and Injury
===================

Designer: Maxicons (https://www.iconfinder.com/sorasak21)
