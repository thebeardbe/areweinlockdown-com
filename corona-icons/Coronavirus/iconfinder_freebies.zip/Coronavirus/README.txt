Coronavirus
===========

Designer: Photo3idea studio (https://www.iconfinder.com/photo3idea)
